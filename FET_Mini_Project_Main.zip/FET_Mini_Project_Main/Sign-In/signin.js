$(document).ready(function () {
  //validate User Type
  function validateUserType() {
    if ($('input[name="role"]:checked').length != 0) {
      return true;
    } else {
      alert("please select User Type!!");
      return false;
    }
  }

  //validate Email
  function validateEmail() {
    var pattern = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/;
    var email = $("#email").val();
    if (pattern.test(email)) {
      return true;
    } else {
      alert("Invalid Email Pattern!!");
      return false;
    }
  }

  //validate Password
  function validatePassword() {
    if (
      ($("#password").val().length < 3 && $("#password").val().length > 50) ||
      $.trim($("#password").val()) == ""
    ) {
      alert("please enter valid Password");
      return false;
    } else {
      return true;
    }
  }

  $("#login").click(function (e) {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    if (validateUserType() && validateEmail() && validatePassword()) {
      if ($('input[name="role"]:checked').val() === "Artist") {
        $.get("http://localhost:3000/Artist", function (data, status) {
          for (var i = 0; i < data.length; i++) {
            if (
              $("#email").val() === data[i].Email &&
              $("#password").val() === data[i].Password
            ) {
              var imgPath = data[i].Profile_Pic;
              var actualPath = imgPath.replace("C:\\fakepath\\", "../images/");
              sessionStorage.setItem("Name", data[i].Name);
              sessionStorage.setItem("Artist_Img", actualPath);
              sessionStorage.setItem("Email", data[i].Email);
              const page = window.open("../Artist_Dash/artistdasboard.html");
              page.addEventListener("DOMContentLoaded", () => {
                // Now we can access the element on the other page
                const name = page.document.getElementById("artist_name");
                const artist_img = page.document.getElementById("artist_img");
                const email = page.document.getElementById("artist_email");
                name.innerHTML = sessionStorage.getItem("Name");
                artist_img.setAttribute(
                  "src",
                  sessionStorage.getItem("Artist_Img")
                );
                email.innerHTML = sessionStorage.getItem("Email");
              });
            }
          }
        });
      } else {
        $.get("http://localhost:3000/User", function (data, status) {
          for (var i = 0; i < data.length; i++) {
            if (
              $("#email").val() === data[i].Email &&
              $("#password").val() === data[i].Password
            ) {
              var imgPath2 = data[i].Profile_Pic;
              var actualPath2 = imgPath2.replace(
                "C:\\fakepath\\",
                "../images/"
              );
              sessionStorage.setItem("Name", data[i].Name);
              sessionStorage.setItem("User_Img", actualPath2);
              sessionStorage.setItem("Email", data[i].Email);
              sessionStorage.setItem("Contact_No", data[i].Contact_No);
              const page = window.open("../User_Dash/userdashboard.html");
              page.addEventListener("DOMContentLoaded", () => {
                // Now we can access the element on the other page
                const name = page.document.getElementById("user_name");
                const user_img = page.document.getElementById("user_img");
                const email = page.document.getElementById("user_email");
                const contactNo =
                  page.document.getElementById("user_contactNo");
                name.innerHTML = sessionStorage.getItem("Name");
                user_img.setAttribute(
                  "src",
                  sessionStorage.getItem("User_Img")
                );
                email.innerHTML = sessionStorage.getItem("Email");
                contactNo.innerHTML = sessionStorage.getItem("Contact_No");
              });
            }
          }
        });
      }
    }
  });
});
